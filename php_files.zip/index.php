<?php
include 'connect.php';
$conn = OpenCon();
echo "Connected Successfully";
CloseCon($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>PINBALL SCOREBOARD</title>
</head>

    <body>
        <h1>PINBALL SCOREBOARD</h1>


    <table align="center" border="1" cellspacing="1" cellpadding="4">
      <t>
            <th>Player ID</th>
            <th>Punkte</th>

          </t>
<?php
    while($row=mysql_fetch_assoc($result))
    {
?>
    <tr>
        <td><?php echo $row['id']; ?> </td>
        <td><?php echo $row['score']; ?> </td>
    </tr>
<?php
    }
?>
    </table>
    </body>
</html>