<?php
    include("connect.php");
    $SQL = "INSERT INTO u302911044_flipr.data (score) VALUES (".$_GET["score"]."')";     
    mysql_query($SQL);
    header("Location: index.php");
?>