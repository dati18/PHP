<?php
function OpenCon()
 {
 $dbhost = "127.0.0.1:3306";
 $dbuser = "u302911044_dat";
 $dbpass = "abc";
 $db = "u302911044_flipr";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>