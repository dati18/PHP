<?php
$MyUsername = "u302911044_dat";  
$MyPassword = "abc123";
$MyHostname = "localhost";

$dbh = mysql_pconnect($MyHostname , $MyUsername, $MyPassword);
$selected = mysql_select_db("u302911044_flipr",$dbh); //database name
?>